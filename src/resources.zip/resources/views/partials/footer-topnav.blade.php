<footer class="main-footer">
    <div class="container">
        <div class="pull-right hidden-xs">
            <b>Phiên bản</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2017 <a href="{{ url('/') }}">{{ config('app.name') }}</a>.</strong> Toàn quyền bảo lưu.
    </div>
    <!-- /.container -->
</footer>