@extends('layouts.topnav')

@section('page-header','')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-body">
                    <h3>Lỗi: 403 - Bạn không có quyền thực hiện thao tác này.</h3>
                </div>
            </div>
        </div>
    </div>
@endsection
